var connectionId = -1;
var placeHolder = "Select a port.";
var portApp = null;
var recvData = [];
var recieving = false;

var charsBase64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function ab_to_b64(arraybuffer) {
	var bytes = new Uint8Array(arraybuffer), i, len = bytes.length, base64 = '';

	for (i = 0; i < len; i += 3) {
		base64 += charsBase64[bytes[i] >> 2];
		base64 += charsBase64[((bytes[i] & 3) << 4) | (bytes[i + 1] >> 4)];
		base64 += charsBase64[((bytes[i + 1] & 15) << 2) | (bytes[i + 2] >> 6)];
		base64 += charsBase64[bytes[i + 2] & 63];
	}

	if ((len % 3) === 2) {
		base64 = base64.substring(0, base64.length - 1) + '=';
	} else if (len % 3 === 1) {
		base64 = base64.substring(0, base64.length - 2) + '==';
	}

	return base64;
}

function b64_to_ab(base64) {
	var bufferLength = base64.length * 0.75, len = base64.length, i, p = 0, encoded1, encoded2, encoded3, encoded4;
	if (base64[base64.length - 1] === '=') {
		--bufferLength;
		if (base64[base64.length - 2] === '=') {
			--bufferLength;
		}
	}

	var arraybuffer = new ArrayBuffer(bufferLength), bytes = new Uint8Array(arraybuffer);
	for (i = 0; i < len; i += 4) {
		encoded1 = charsBase64.indexOf(base64[i]);
		encoded2 = charsBase64.indexOf(base64[i + 1]);
		encoded3 = charsBase64.indexOf(base64[i + 2]);
		encoded4 = charsBase64.indexOf(base64[i + 3]);
		bytes[p++] = (encoded1 << 2) | (encoded2 >> 4);
		bytes[p++] = ((encoded2 & 15) << 4) | (encoded3 >> 2);
		bytes[p++] = ((encoded3 & 3) << 6) | (encoded4 & 63);
	}

	return arraybuffer;
}

document.addEventListener('DOMContentLoaded', function() {
	console.log('DOMContentLoaded');
	var portOptions = document.getElementById('ports');
	var onGetDevices = function(ports) {
		var portOption = document.createElement('option');
		portOption.value = portOption.innerText = placeHolder;
		portOptions.appendChild(portOption);
	  for (var i=0; i<ports.length; i++) {
		console.log(ports[i].path);
		var portOption = document.createElement('option');
		portOption.value = portOption.innerText = ports[i].path;
		portOptions.appendChild(portOption);
	  }
	}
	chrome.serial.getDevices(onGetDevices);
	
	portOptions.onchange = function() {
    if (connectionId != -1) {
      chrome.serial.disconnect(connectionId, openSelectedPort);
      return;
    }
    openSelectedPort();
  };
});

function openSelectedPort() {
  var portOptions = document.getElementById('ports');
  var selectedPort = portOptions.options[portOptions.selectedIndex].value;
  if( selectedPort == placeHolder )
  {
	  setStatus('Select a port.');
  } else {
	  setStatus('Attempting to connect.');
    chrome.serial.connect(selectedPort, {bitrate: 57600}, onConnect);
	/*
	chrome.serial.connect(selectedPort, {
    bitrate: options.baudrate || 57600
  }, onConnect);
  */
  }
}

function onConnect(connectionInfo) {
  if (!connectionInfo) {
    setStatus('Could not open');
    return;
  }
  connectionId = connectionInfo.connectionId;
  setStatus('Connected');

  chrome.serial.onReceive.addListener(function(obj){
        if(connectionId == obj.connectionId){
          //var data = new Uint8Array(obj.data);
          //self.emit("data", data);
		  setStatus( ab2str(obj.data));
		  //recvData.push( ab_to_b64(obj.data) );
		  //recvData = appendBuffer( recvData, obj.data );
		  //console.log( recvData );
		  if ( recieving ) {
			portApp.postMessage(["serialRecv", "COM15", ab_to_b64(obj.data)]);
		  } else {
			recvData.push( ab_to_b64(obj.data) );
		  }
        }
  });
}

function write(data) {
  function onWrite() {
    // log("onWrite", arguments);
  }

  data = new Uint8Array(data);
  // console.log("OUT", data);
  if(connectionId != -1 ){
    chrome.serial.send(connectionId, data.buffer, onWrite);
  }

};

var appendBuffer = function(buffer1, buffer2) {
      var tmp = new Uint8Array(buffer1.byteLength + buffer2.byteLength);
      tmp.set(new Uint8Array(buffer1), 0);
      tmp.set(new Uint8Array(buffer2), buffer1.byteLength);
      return tmp.buffer;
};

function ab2str(buf) {
  return String.fromCharCode.apply(null, new Uint8Array(buf));
}

function str2ab(str) {
  var buf = new ArrayBuffer(str.length*2); // 2 bytes for each char
  var bufView = new Uint8Array(buf);
  for (var i=0, strLen=str.length; i<strLen; i++) {
    bufView[i] = str.charCodeAt(i);
  }
  return buf;
}

function setStatus(status) {
  document.getElementById('status').innerText = status;
}

chrome.runtime.onSuspend.addListener( function() {
	connectionId = -1;
	var portOptions = document.getElementById('ports');
	portOptions.value = placeHolder;
});

/*
var port = chrome.runtime.connect({name: "knockknock"});
port.postMessage({joke: "Knock knock"});

port.onMessage.addListener(function(msg) {
	console.log(msg);
  if (msg.question == "Who's there?")
  {
    port.postMessage({answer: "Madame"});
	console.log("Madame");
  }
  else if (msg.question == "Madame who?")
  {
    port.postMessage({answer: "Madame... Bovary"});
	console.log("Madame... Bovary");
  }
});

chrome.runtime.onConnect.addListener(function(port) {
  console.assert(port.name == "knockknock");
	console.log(port.name);
  port.onMessage.addListener(function(msg) {
	  conosle.log(msg);
    if (msg.joke == "Knock knock")
	{
      port.postMessage({question: "Who's there?"});
	console.log("Who's there?");
	}
    else if (msg.answer == "Madame")
	{
      port.postMessage({question: "Madame who?"});
	console.log("Madame who?");
	}
    else if (msg.answer == "Madame... Bovary")
	{
      port.postMessage({question: "I don't get it."});
	console.log("I don't get it.");
	}
  });
});*/

chrome.runtime.onConnectExternal.addListener(function listener(port) {
	console.log("External connection event");
	console.log(port);
	portApp = port;

	port.onMessage.addListener(function(msg) {
	  console.log(msg);
	  if ( msg[1] == "version" ) {
		console.log("version");
		port.postMessage(["@", msg[0], "awesome"]);
	  }
	  if ( msg[1][0] == "serial_list" && connectionId != -1 ) {
		console.log("serial_list");
		port.postMessage(["@", msg[0], ["COM15"]]);
	  }
	  if ( msg[1][0] == "serial_open_raw" )  {
		console.log("serial_open_raw");
		// open serial port named msg[1][1] --- COM15 for now
		port.postMessage(["@", msg[0], [1]]);
	  }
	  if ( msg[1][0] == "claim" )  {
		console.log("claim")
		//port.postMessage(["@", msg[0], "serial_is_open"]); //"serial_is_open" msg[1][1]
	  }
	  if ( msg[1][0] == "serial_send_raw" )  {
		console.log("serial_send_raw");
		console.log( msg[1][2] );
		write( b64_to_ab(msg[1][2]) );
		port.postMessage(["@", msg[0],  "serial_is_open"]);
	  }
	  if ( msg[1][0] == "serial_recv_start" )  {
		console.log("serial_recv_start");
		
		/*var recv = function(obj){
			console.log("recv");
			console.log(obj);
			if(connectionId == obj.connectionId){
			  var data = new Uint8Array(obj.data);
			  console.log("serialRecv");
			  console.log(data);
			  port.postMessage(["serialRecv", "COM15", ab_to_b64(obj.data)]);
			}
		}*/
		port.onMessage.addListener(function recv_closer(msg) {
		  console.log(msg);
		  if ( msg[1][0] == "serial_close" ) {
			console.log("serial_close");
			recieving = false;
			//chrome.serial.onReceive.removeListener(recv);
			port.onMessage.removeListener(recv_closer);
			port.postMessage(["@", msg[0], ["close"]]);
		  }
		});
		//chrome.serial.onReceive.addListener(recv);
		recieving = true;
		while( recvData.length > 0 ) {
			data = recvData.shift();
			//var data = ab_to_b64( recvData );//.shift()
			console.log( data );
			port.postMessage(["serialRecv", "COM15", data]);
		}
	  }
	});
});


